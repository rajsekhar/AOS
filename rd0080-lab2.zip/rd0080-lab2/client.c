#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>

struct node
{
    int a;
    int b;
    char c[10];
};

int main(int argc, char const *argv[])
{
    int socketFD, port;
    struct sockaddr_in serverAddress, clientAddress;
    struct hostent *server;
    if (argc < 3)
    {
        fprintf(stderr, "usage %s hostname port\n", argv[0]);
        exit(0);
    }
    port = atoi(argv[2]);
    socketFD = socket(AF_INET, SOCK_STREAM, 0);
    if (socketFD < 0)
        fprintf(stderr,"ERROR opening socket");
    server = gethostbyname(argv[1]);
    if (server == NULL)
    {
        fprintf(stderr, "ERROR, no such host\n");
        exit(0);
    }
    bzero((char *)&serverAddress, sizeof(serverAddress));
    serverAddress.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serverAddress.sin_addr.s_addr, server->h_length);
    serverAddress.sin_port = htons(port);

    clientAddress.sin_family = AF_INET;
    clientAddress.sin_port = htons(port);
    clientAddress.sin_addr.s_addr = htonl(INADDR_ANY);

    if (connect(socketFD, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0)
        fprintf(stderr,"ERROR connecting");

    struct node temp;
    temp.a = 21;
    temp.b = 32;
    temp.c[0] = 'T';
    temp.c[1] = 'E';
    temp.c[2] = 'S';
    temp.c[3] = 'T';
    sendto(socketFD, (void *)&temp, sizeof(temp), 0, (struct sockaddr *)&serverAddress, sizeof(serverAddress));
    printf("%s - %s", inet_ntoa(serverAddress.sin_addr), inet_ntoa(clientAddress.sin_addr));

    return 0;
}